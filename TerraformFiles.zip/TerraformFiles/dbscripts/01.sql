CREATE TABLE [dbo].[Products](
	[ProductID] [int] NULL,
	[ProductName] [varchar](1000) NULL,
	[Quantity] [int] NULL,
	[ProductImage] [varchar](1000) NULL
) ON [PRIMARY]

INSERT INTO Products(ProductID,ProductName,Quantity,ProductImage) VALUES (1,'Azure Virtual Machine',100,'https://${storage_account_name}.blob.core.windows.net/${app_container_name}/VM.jpg')
StorageAccount
INSERT INTO Products(ProductID,ProductName,Quantity,ProductImage) VALUES (2,'Azure Virtual Machine',200,'https://${storage_account_name}.blob.core.windows.net/${app_container_name}/StorageAccount.jpg')

INSERT INTO Products(ProductID,ProductName,Quantity,ProductImage) VALUES (3,'Azure Public IP',300,'https://${storage_account_name}.blob.core.windows.net/${app_container_name}/PublicIp.jpg')

     	